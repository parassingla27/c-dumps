using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Routing;
using Microsoft.AspNet.FriendlyUrls;

namespace LearnCentre
{
    public static class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.MapPageRoute("default", "Home", "~/Default.aspx");
            routes.MapPageRoute("AboutPageRoute", "AboutUs", "~/About.aspx");
            routes.MapPageRoute("RegistrationPageRoute", "Registration", "~/Register.aspx");
            routes.MapPageRoute("TestPageRoute", "Test", "~/Test.aspx");
            routes.MapPageRoute("QuestionsPageRoute", "Questions/{QuizID}", "~/Questions.aspx");
            routes.MapPageRoute("ResultPageRoute", "Success", "~/Result.aspx");
            routes.EnableFriendlyUrls();
        }
    }
}
