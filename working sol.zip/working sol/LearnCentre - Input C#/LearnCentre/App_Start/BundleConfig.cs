﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace LearnCentre
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254726
        public static void RegisterBundles(BundleCollection bundles)
        {
              bundles.Add(new ScriptBundle("~/bundles/WebFormsJs").Include("~/Scripts/WebForms/WebForms.js","~/Scripts/WebForms/WebUIValidation.js"
                  , "~/Scripts/WebForms/MenuStandards.js", "~/Scripts/WebForms/GridView.js"
                  , "~/Scripts/WebForms/DetailsView.js", "~/Scripts/WebForms/TreeView.js"
                  , "~/Scripts/WebForms/WebParts.js", "~/Scripts/WebForms/Focus.js"));

        }
       
    }
}