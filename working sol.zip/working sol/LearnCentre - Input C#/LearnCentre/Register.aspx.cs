﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data;
using Microsoft.AspNet.FriendlyUrls;
namespace LearnCentre
{
    public partial class Register : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            //Add your Code here for Requirement 5a
                if (Page.IsValid == true)
                {
                    if(Regex.IsMatch(txtcontact.Text, "^[0-9]{10}"))
                    {
                    // Static method:
                    //if (Regex.IsMatch(txtemail.Text, @"^^(?("")("".+?""@)|(([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-zA-Z])@))(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,6}))$"))
                        if (Regex.IsMatch(txtemail.Text, @"^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$"))
                        {
                        DataTable dt=new DataTable();
                        SqlConnection con = new SqlConnection("Data Source=CTSC00914947701;Initial Catalog=QuizDB;Integrated Security=True");
                        con.Open();
                        SqlCommand cmd = new SqlCommand("Select ContactNo from [StudentDetails] where contactno='" + Convert.ToInt64(txtcontact.Text) + "'",con);

                        string a=Convert.ToString(cmd.ExecuteScalar());
                        if (string.IsNullOrEmpty(a))
                        {

                        }

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dt);
                        con.Close();
                        if (string.IsNullOrEmpty(a))
                        {
                        UserDetails user = new UserDetails();
                        //Insert the code here to initialize the members of UserDetails class as per the details entered by the user.
                        user.fname = txtfname.Text;
                        user.lname = txtlname.Text;
                        user.email = txtemail.Text;
                        user.cno = Convert.ToInt64(txtcontact.Text);
                        user.add = txtaddress.Text;
                        user.eduQual = txteduqu.Text;
                        user.intCourse = txtintcour.Text;
                        Session.Add("userDetails", user);

                        //Redirect to Test.aspx Web page
                        Response.RedirectToRoute("TestPageRoute");
                        }
                        else
                        {
                            ErrorMessage.Text="contact number already exists";
                        }
                        //Server.Transfer("Test.aspx");
                        //Response.Redirect("~Test/Test.aspx");

                    }
                    else
                    {
                        ErrorMessage.Text="Invalid Email Address";
                    }
                    }
                    else
                    {
                        ErrorMessage.Text = "Invalid Mobile Number";
                    }
                }

                
            }

    }
}